export class Vehicle {
  _id: number;
  title: string = '';
  description: string = '';
  price: number;
  token: string = '';

}
