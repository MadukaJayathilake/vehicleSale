export const CONFIG = {
    secretKey : "parane"
}